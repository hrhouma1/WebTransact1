package com.exemple.demo.repository;

import com.exemple.demo.model.Card;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CardRepository extends JpaRepository<Card, Integer> {
    // Laisser vide pour le moment
}