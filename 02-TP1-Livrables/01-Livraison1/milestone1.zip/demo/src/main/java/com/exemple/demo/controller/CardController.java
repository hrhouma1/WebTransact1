package com.exemple.demo.controller;

import com.exemple.demo.model.Card;
import com.exemple.demo.repository.CardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cards")
public class CardController {

    @Autowired
    private CardRepository cardRepository;

    @GetMapping("/all")
    public List<Card> getAllCards() {
        return cardRepository.findAll();
    }

    @PostMapping("/add")
    public Card addCard(@RequestBody Card card) {
        return cardRepository.save(card);
    }
}