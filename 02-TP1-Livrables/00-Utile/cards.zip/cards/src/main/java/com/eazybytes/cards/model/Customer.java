package com.eazybytes.cards.model;

import lombok.*;


@Data
public class Customer {

	private int customerId;

}
